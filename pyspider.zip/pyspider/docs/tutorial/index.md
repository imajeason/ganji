pyspider Tutorial
=================

> The best way to learn how to scrap is learning how to make it.

* [Level 1: HTML and CSS Selector](HTML-and-CSS-Selector)
* [Level 2: AJAX and More HTTP](AJAX-and-more-HTTP)
* [Level 3: Render with PhantomJS](Render-with-PhantomJS)

If you have problem using pyspider, [user group](https://groups.google.com/group/pyspider-users) is a place for discussing.
